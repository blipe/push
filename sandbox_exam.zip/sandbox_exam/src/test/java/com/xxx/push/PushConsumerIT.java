package com.xxx.push;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.support.SendResult;
import org.springframework.kafka.test.context.EmbeddedKafka;

import com.xxx.push.model.Exchange;
import com.xxx.push.model.Request;
import com.xxx.push.model.Request.Builder;
import com.xxx.push.model.Type;

import lombok.extern.slf4j.Slf4j;

@Slf4j
//@ExtendWith(TestContainersSetupExtension.class)
@EmbeddedKafka(controlledShutdown = true, /* topics = { "" }, */ partitions = Constants.PARTITIONS)
public class PushConsumerIT extends IntegrationPushBase {

    @BeforeEach
    public void setup() {
        log.info("setup");
        super.setup();

        String brokers = getProperty("spring.embedded.kafka.brokers");

        log.info("brokers: {}", brokers);

        String kafkaPort = brokers.replace("127.0.0.1:", "");
        System.setProperty("kafka.mapped.port", kafkaPort);
    }

    @AfterEach
    public void tearDown() {
        log.info("tearDown");
    }

    private Random random = new Random();

    @Test
    public void testPushConsumer1mil() throws Exception {
        long startTime = System.currentTimeMillis();

        for (int i = 0; i < Constants.TOTAL_EXCHANGES; i++) {
            Request request;

            List<String> tokens = List.of();

            int rand = random.nextInt(100);
            switch (rand) {
            case 99: {
                tokens = List.of();
                break;
            }
            case 98: {
                tokens = List.of("token1", "token2");
                break;
            }
            default: {
                tokens = List.of("token1");
                break;
            }
            }

            Builder requestBuilder = Request.newBuilder();
            if (i % 2 == 0) {
                request = requestBuilder.setSource("source").setRequestId("0" + i).setProfileId("x").setExpiration(System.currentTimeMillis() + Constants.EXPIRATION_SHORT).setMessage("message" + i).setType(Type.ANDROID).setTokens(tokens)
                        .setParams(Map.of()).build();
            } else {
                request = requestBuilder.setSource("source").setRequestId("0" + i).setProfileId("y").setExpiration(System.currentTimeMillis() + Constants.EXPIRATION_SHORT).setMessage("message" + i).setType(Type.APPLE).setTokens(tokens)
                        .setParams(Map.of()).build();
            }

            Exchange exchange = Exchange.newBuilder().setRequest(request).setMetadata(Map.of()).build();

            String requestId = request.getRequestId();
            String key = requestId;

            CompletableFuture<SendResult<String, byte[]>> future = sendMessageAsync(REQUEST_TOPIC, requestId, key, exchange);
            future.whenComplete((result, ex) -> {
                if (ex != null) {
                    ex.printStackTrace();
                } else {
                    //System.out.println("sent rec: " + rec + ", result: " + result);
                }
            });
        }

        while (true) {
            long responseCount = Stats.responseListenCount.get();
            if (responseCount < Constants.TOTAL_EXCHANGES) {
                System.out.println("progress: " + ((double) responseCount / Constants.TOTAL_EXCHANGES * 100.0) + "%");
                Thread.sleep(1000);
            } else {
                break;
            }
        }

        long endTime = System.currentTimeMillis();

        Thread.sleep(10 * 1000);

        Stats.dump();

        log.info((((double) endTime - startTime) / 1000.0 / 60.0) + " mins");
        log.info(Constants.TOTAL_EXCHANGES / ((double) endTime - startTime) * 1000.0 + " msg/sec");

        log.info("done");
    }
}
