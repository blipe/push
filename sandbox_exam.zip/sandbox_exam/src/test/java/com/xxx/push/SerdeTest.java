package com.xxx.push;

import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;

import com.xxx.push.model.Exchange;
import com.xxx.push.serde.AvroDeserializer;
import com.xxx.push.serde.AvroSerializer;

public class SerdeTest {
    public static void main(String[] args) throws InstantiationException, IllegalAccessException {
        Exchange exchange = Exchange.newBuilder().build();

        byte[] bytes = new AvroSerializer(Exchange.getClassSchema()).serialize("topic", exchange);

        exchange = (Exchange) new AvroDeserializer(Exchange.getClassSchema()).deserialize("topic", bytes);

        System.out.println(exchange);

        {
            Object returnObject = null;

            try {

                if (bytes != null) {
                    DatumReader<GenericRecord> datumReader = new GenericDatumReader<>();
                    Decoder decoder = DecoderFactory.get().binaryDecoder(bytes, null);
                    returnObject = datumReader.read(null, decoder);
                    //log.info("deserialized data='{}'", returnObject.toString());
                }
            } catch (Exception e) {
                //log.error("Unable to Deserialize bytes[] ", e);
                e.printStackTrace();
            }

            System.out.println(returnObject);

        }
    }
}
