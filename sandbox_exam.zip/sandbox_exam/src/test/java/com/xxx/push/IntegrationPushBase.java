package com.xxx.push;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.awaitility.Awaitility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.utils.ContainerTestUtils;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;

import com.xxx.push.config.KafkaPushConfiguration;
import com.xxx.push.kafka.KafkaUtil;
import com.xxx.push.model.Exchange;
import com.xxx.push.serde.AvroSerializer;
import com.xxx.push.util.Formatter;

import brave.Tracer;
import io.micrometer.core.instrument.composite.CompositeMeterRegistry;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest(classes = { KafkaPushConfiguration.class })
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
@ActiveProfiles("test")
@EnableKafka
public abstract class IntegrationPushBase implements Constants {

    @Autowired
    private Environment environment;

    @Autowired
    @Qualifier("tracer")
    private Tracer tracer;

    @Autowired
    @Qualifier("metrics")
    private CompositeMeterRegistry metrics;

    @Autowired
    @Qualifier("kafkaTemplate")
    protected KafkaTemplate<String, byte[]> kafkaTemplate;

    @Autowired
    private EmbeddedKafkaBroker embeddedKafkaBroker;

    @Autowired
    private KafkaListenerEndpointRegistry registry;

    public String getProperty(String key) {
        return environment.getProperty(key);
    }

    public void setup() {
        // Wait until the partitions are assigned.
        registry.getListenerContainers().stream().forEach(container -> {
            log.info("waiting for assignment container: " + container + ", groupId: " + container.getGroupId() + ", listenerId: " + container.getListenerId());
            ContainerTestUtils.waitForAssignment(container, embeddedKafkaBroker.getPartitionsPerTopic());
            log.info("finished waiting for assignment container: " + container + ", groupId: " + container.getGroupId() + ", listenerId: " + container.getListenerId());
        });
    }

    public SendResult<String, byte[]> sendMessage(String topic, String eventId, String key, Exchange exchange) throws Exception {
        AvroSerializer<Exchange> serializer = newExchangeSerializer();
        byte[] bytes = serializer.serialize(topic, exchange);

        List<Header> headers = new ArrayList<>();
        headers.add(new RecordHeader("_client_write_time", KafkaUtil.longToBytes(System.currentTimeMillis())));
        //headers.add(new RecordHeader(KafkaClient.EVENT_ID_HEADER_KEY, eventId != null ? eventId.getBytes() : null));

        final ProducerRecord<String, byte[]> record = new ProducerRecord<>(topic, null, key, bytes, headers);

        final SendResult<String, byte[]> result = kafkaTemplate.send(record).get();
        final RecordMetadata metadata = result.getRecordMetadata();

        if (log.isTraceEnabled()) {
            log.trace(Formatter.format("Sent", record, metadata));
        }

        return result;
    }

    protected AvroSerializer<Exchange> newExchangeSerializer() {
        return new AvroSerializer<>(Exchange.getClassSchema());
    }

    public CompletableFuture<SendResult<String, byte[]>> sendMessageAsync(String topic, String eventId, String key, Exchange exchange) throws Exception {
        AvroSerializer<Exchange> serializer = newExchangeSerializer();
        byte[] bytes = serializer.serialize(topic, exchange);

        List<Header> headers = new ArrayList<>();
        headers.add(new RecordHeader("_client_write_time", KafkaUtil.longToBytes(System.currentTimeMillis())));
        //headers.add(new RecordHeader(KafkaClient.EVENT_ID_HEADER_KEY, eventId != null ? eventId.getBytes() : null));

        final ProducerRecord<String, byte[]> record = new ProducerRecord<>(topic, null, key, bytes, headers);

        final CompletableFuture<SendResult<String, byte[]>> result = kafkaTemplate.send(record);

        if (log.isTraceEnabled()) {
            //log.trace(Formatter.format("Sent", record, metadata));
        }

        return result;
    }

    //    public RecordMetadata sendMessage(String topic, String key, Object payload) throws Exception {
    //        return sendMessage(defaultProducer, topic, key, payload, null);
    //    }
    //
    //    public RecordMetadata sendMessage(Producer producer, String topic, String key, Object payload) throws Exception {
    //        return sendMessage(producer, topic, key, payload, null);
    //    }
    //
    //    public RecordMetadata sendMessage(String topic, String key, Object payload, Map<String, String> headers) throws Exception {
    //        return sendMessage(defaultProducer, topic, key, payload, headers);
    //    }
    //
    //    public RecordMetadata sendMessage(Producer producer, String topic, String key, Object payload, Map<String, String> headers) throws Exception {
    //        final List<Header> recordHeaders = new ArrayList<>();
    //        if(headers!=null && headers.size()>0) {
    //            headers.forEach((headerKey, headerValue) -> recordHeaders.add(new RecordHeader(headerKey, headerValue != null ? headerValue.getBytes() : null)));
    //        }
    //        final ProducerRecord<Long, String> record = new ProducerRecord(topic, null, key, payload, recordHeaders);
    //        final RecordMetadata metadata = (RecordMetadata)producer.send(record).get();
    //        log.debug(Formatter.format("Sent", record, metadata));
    //        return metadata;
    //    }
    //
    //    public Future<RecordMetadata> sendMessageAsync(String topic, String key, Object payload) {
    //        return sendMessageAsync(defaultProducer, topic, key, payload, null);
    //    }
    //
    //    public Future<RecordMetadata> sendMessageAsync(Producer producer, String topic, String key, Object payload) {
    //        return sendMessageAsync(producer, topic, key, payload, null);
    //    }
    //
    //    public Future<RecordMetadata> sendMessageAsync(String topic, String key, Object payload, Map<String, String> headers) {
    //        return sendMessageAsync(defaultProducer, topic, key, payload, headers);
    //    }
    //
    //    public Future<RecordMetadata> sendMessageAsync(Producer producer, String topic, String key, Object payload, Map<String, String> headers) {
    //        final List<Header> recordHeaders = new ArrayList<>();
    //        if(headers!=null && headers.size()>0) {
    //            headers.forEach((headerKey, headerValue) -> recordHeaders.add(new RecordHeader(headerKey, headerValue != null ? headerValue.getBytes() : null)));
    //        }
    //        final ProducerRecord<Long, String> record = new ProducerRecord(topic, null, key, payload, recordHeaders);
    //        return producer.send(record);
    //    }

    public <T> List<ConsumerRecord<String, T>> consumeAndAssert(String testName, Consumer<String, T> consumer, int expectedEventCount, int furtherPolls) throws Exception {
        int defaultAwaitAtMostSeconds = 60;
        return consumeAndAssert(testName, consumer, expectedEventCount, furtherPolls, defaultAwaitAtMostSeconds);
    }

    public <T> List<ConsumerRecord<String, T>> consumeAndAssert(String testName, Consumer<String, T> consumer, int expectedEventCount, int furtherPolls, int awaitAtMostSeconds) throws Exception {
        AtomicInteger totalReceivedEvents = new AtomicInteger();
        AtomicInteger totalExtraPolls = new AtomicInteger(-1);
        AtomicInteger pollCount = new AtomicInteger();
        List<ConsumerRecord<String, T>> events = new ArrayList<>();

        Awaitility.await().atMost(awaitAtMostSeconds, TimeUnit.SECONDS).pollInterval(1, TimeUnit.SECONDS).until(() -> {
            final ConsumerRecords<String, T> consumerRecords = consumer.poll(Duration.ofMillis(100));
            consumerRecords.forEach(record -> {
                log.info(testName + " - received: " + record.value());
                totalReceivedEvents.incrementAndGet();
                events.add(record);
            });
            if (totalReceivedEvents.get() == expectedEventCount) {
                totalExtraPolls.incrementAndGet();
            }
            pollCount.getAndIncrement();
            log.info(testName + " - poll count: " + pollCount.get() + " - received count: " + totalReceivedEvents.get());
            return totalReceivedEvents.get() == expectedEventCount && totalExtraPolls.get() == furtherPolls;
        });
        return events;
    }
}
