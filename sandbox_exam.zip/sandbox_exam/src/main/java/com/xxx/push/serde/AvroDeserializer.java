package com.xxx.push.serde;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.Map;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.BinaryDecoder;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.common.serialization.Deserializer;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AvroDeserializer<T extends SpecificRecordBase> implements Deserializer<T> {

    protected static final ThreadLocal<BinaryDecoder> binaryDecoderReuse = new ThreadLocal<>() {
        @Override
        protected BinaryDecoder initialValue() {
            byte[] bytes = new byte[0];
            BinaryDecoder binaryDecoder = DecoderFactory.get().binaryDecoder(bytes, null);
            return binaryDecoder;
        }
    };

    protected Schema schema;
    protected boolean useSpecific = true;

    public AvroDeserializer(Schema schema) {
        this.schema = schema; //(Class<T> targetType).newInstance().getSchema();
    }

    @Override
    public void configure(Map configs, boolean isKey) {
    }

    @Override
    public T deserialize(String topic, byte[] bytes) {
        T payload = null;

        try {

            if (bytes != null) {
                DatumReader<GenericRecord> datumReader;
                if (useSpecific) {
                    datumReader = new SpecificDatumReader<>(schema);
                } else {
                    datumReader = new GenericDatumReader<>(schema);//GenericRecord
                }
                BinaryDecoder binaryDecoder = DecoderFactory.get().binaryDecoder(bytes, binaryDecoderReuse.get());
                payload = (T) datumReader.read(null, binaryDecoder);
                if (log.isTraceEnabled()) {
                    log.trace("deserialized data='{}'", payload.toString());
                }
            }
        } catch (IOException e) {
            log.error("Unable to Deserialize bytes[]", e);
            throw new UncheckedIOException(e);
        }

        return payload;
    }

    @Override
    public void close() {
        // do nothing
    }
}