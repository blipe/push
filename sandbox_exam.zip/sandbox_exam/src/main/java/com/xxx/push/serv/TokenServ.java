package com.xxx.push.serv;

import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.xxx.push.Constants;
import com.xxx.push.Stats;
import com.xxx.push.model.Exchange;

import brave.Tracer;
import io.micrometer.core.instrument.composite.CompositeMeterRegistry;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class TokenServ {
    @Autowired
    @Qualifier("tracer")
    private Tracer tracer;

    @Autowired
    @Qualifier("metrics")
    private CompositeMeterRegistry metrics;

    private AtomicLong counter = new AtomicLong();

    private Random random = new Random();

    public List<String> lookup(Exchange exchange) {
        List<String> tokens = List.of();

        long num = counter.getAndIncrement();
        try {
            long time = System.currentTimeMillis();

            Thread.sleep(Constants.TOKEN_SERV_SLEEP_SHORT);

            int rand = random.nextInt(100);
            switch (rand) {
            case 99: {
                tokens = List.of();
                break;
            }
            case 98: {
                tokens = List.of("token1", "token2");
                break;
            }
            default: {
                tokens = List.of("token1");
                break;
            }
            }

            Stats.tokenServCallCount.incrementAndGet();
            Stats.tokenServCallTime.addAndGet(System.currentTimeMillis() - time);

        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            log.error("serv interrupted", e);
        }

        return tokens;
    }
}
