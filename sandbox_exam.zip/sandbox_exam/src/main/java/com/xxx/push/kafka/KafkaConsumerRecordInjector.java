package com.xxx.push.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeader;

import brave.propagation.TraceContext;

class KafkaConsumerRecordInjector implements TraceContext.Injector<ConsumerRecord<String, byte[]>> {
    @Override
    public void inject(TraceContext traceContext, ConsumerRecord<String, byte[]> record) {
        Headers headers = record.headers();

        Long traceId = traceContext.traceId();
        Long parentId = traceContext.parentId();
        Long spanId = traceContext.spanId();

        if (traceId != null) {
            headers.add(new RecordHeader("_trace_id", KafkaUtil.longToBytes(traceId)));
        }
        if (parentId != null) {
            headers.add(new RecordHeader("_parent_id", KafkaUtil.longToBytes(parentId)));
        }
        if (spanId != null) {
            headers.add(new RecordHeader("_span_id", KafkaUtil.longToBytes(spanId)));
        }
    }
}
