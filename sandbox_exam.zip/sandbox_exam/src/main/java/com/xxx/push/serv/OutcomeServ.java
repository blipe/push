package com.xxx.push.serv;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.xxx.push.Constants;
import com.xxx.push.Stats;
import com.xxx.push.model.Exchange;

import brave.Tracer;
import io.micrometer.core.instrument.composite.CompositeMeterRegistry;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class OutcomeServ {
    @Autowired
    @Qualifier("tracer")
    private Tracer tracer;

    @Autowired
    @Qualifier("metrics")
    private CompositeMeterRegistry metrics;

    private AtomicLong counter = new AtomicLong();

    public void store(Exchange exchange) {
        long num = counter.getAndIncrement();
        try {
            long time = System.currentTimeMillis();

            Thread.sleep(Constants.DB_SERV_SLEEP_SHORT);

            Stats.outcomeServCallCount.incrementAndGet();
            Stats.outcomeServCallTime.addAndGet(System.currentTimeMillis() - time);

        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            log.error("serv interrupted", e);
        }
    }
}
