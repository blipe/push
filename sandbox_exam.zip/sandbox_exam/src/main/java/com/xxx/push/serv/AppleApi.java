package com.xxx.push.serv;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Component;

import com.xxx.push.Constants;
import com.xxx.push.Stats;
import com.xxx.push.model.Response;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AppleApi extends Api {
    private AtomicLong counter = new AtomicLong();

    @Override
    public Response postHttp(String token) throws ApiException {
        Response response;

        long num = counter.getAndIncrement();
        try {
            long time = System.currentTimeMillis();

            if (num > 0 && num % Constants.API_LONG_MOD == 0) {
                Thread.sleep(Constants.APPLE_API_SLEEP_LONG);
            } else {
                Thread.sleep(Constants.APPLE_API_SLEEP_SHORT);
            }

            if (num % Constants.API_EX_MOD == 0) {
                throw new ApiException("NetworkError");
            } else if (num % Constants.API_ERR_MOD == 0) {
                response = FAILED;
            } else {
                response = SUCCESS;
            }

            Stats.appleApiCallCount.incrementAndGet();
            Stats.appleApiCallTime.addAndGet(System.currentTimeMillis() - time);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            log.error("api interrupted", e);
            response = INTERRUPTED;
        }
        Stats.appleApiResponseCodes.computeIfAbsent(response.getCode(), (k) -> new AtomicLong()).incrementAndGet();
        return response;
    }
}
