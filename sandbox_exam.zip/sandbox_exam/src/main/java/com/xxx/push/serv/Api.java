package com.xxx.push.serv;

import java.util.List;
import java.util.concurrent.ExecutorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.xxx.push.model.Exchange;
import com.xxx.push.model.Response;

import brave.Tracer;
import io.micrometer.core.instrument.composite.CompositeMeterRegistry;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class Api {
    public static final Response SUCCESS = new Response(200, "OK", "OK");
    public static final Response NOT_FOUND = new Response(404, "NotFound", "NotFound");
    public static final Response EXPIRED = new Response(408, "Expired", "Expired");
    public static final Response TOO_MANY = new Response(429, "TooMany", "TooMany");
    public static final Response FAILED = new Response(500, "Failed", "Failed");
    public static final Response INTERRUPTED = new Response(503, "Interrupted", "Interrupted");

    @Autowired
    @Qualifier("tracer")
    private Tracer tracer;

    @Autowired
    @Qualifier("metrics")
    private CompositeMeterRegistry metrics;

    private int maxAttempts = 3;

    public Response handle(ExecutorService executor, Exchange exchange) {
        boolean success = false;

        List<String> tokens = exchange.getRequest().getTokens();
        int i = 0;
        loop: for (; i < tokens.size(); i++) {
            String token = tokens.get(i);

            Response response = null;
            Throwable exception = null;
            for (int attempt = 0; attempt < maxAttempts; attempt++) {
                if (attempt > 0) {
                    String reason;
                    if (response != null) {
                        reason = String.valueOf(response);
                    } else {
                        reason = String.valueOf(exception);
                    }
                    log.warn("retrying {} of {} due to {}", attempt, maxAttempts - 1, reason);
                }

                try {
                    response = postHttp(token);
                    exception = null;
                    if (isSuccess(response)) {
                        success = true;
                        break loop;
                    }
                    if (!isRetryable(response)) {
                        break;
                    }
                } catch (ApiException e) {
                    log.warn("api exception", e);
                    exception = e;
                    response = null;
                }

                if (attempt + 1 < maxAttempts) {
                    try {
                        Thread.sleep(attempt * 100);
                    } catch (InterruptedException e) {
                        exception = e;
                        response = null;
                        break;
                    }
                }
            }

            if (response != null) {
                store(exchange, response);
            } else {
                store(exchange, exception);
            }
        }

        //remaining
        for (int j = i; j < tokens.size(); j++) {
            String token = tokens.get(j);

            Runnable task = () -> {
                Response response = null;
                Throwable exception = null;
                try {
                    response = postHttp(token);
                    exception = null;
                } catch (ApiException e) {
                    log.warn("api exception", e);
                    exception = e;
                    response = null;
                }

                if (response != null) {
                    store(exchange, response);
                } else {
                    store(exchange, exception);
                }
            };
            executor.submit(task);
        }

        if (success) {
            return SUCCESS;
        } else {
            return FAILED;
        }
    }

    protected abstract Response postHttp(String token) throws ApiException;

    public void store(Exchange exchange, Response response) {

    }

    public void store(Exchange exchange, Throwable exception) {

    }

    protected boolean isSuccess(Response response) {
        return response.getCode() == 200;
    }

    protected boolean isRetryable(Response response) {
        return response.getCode() == 429 || response.getCode() == 500 || response.getCode() == 502 || response.getCode() == 503 || response.getCode() == 504;
    }
}
