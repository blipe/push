package com.xxx.push.serde;

//import javax.xml.bind.DatatypeConverter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.Map;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.common.serialization.Serializer;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AvroSerializer<T extends SpecificRecordBase> implements Serializer<T> {

    protected static final ThreadLocal<BinaryEncoder> binaryEncoderReuse = new ThreadLocal<>() {
        @Override
        protected BinaryEncoder initialValue() {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            BinaryEncoder binaryEncoder = EncoderFactory.get().binaryEncoder(byteArrayOutputStream, null);
            return binaryEncoder;
        }
    };

    protected Schema schema;
    protected boolean useSpecific = false;

    public AvroSerializer(Schema schema) {
        this.schema = schema; //(Class<T> targetType).newInstance().getSchema();
    }

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        // do nothing
    }

    @Override
    public byte[] serialize(String topic, T payload) {
        byte[] bytes = null;
        try {
            if (payload != null) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                BinaryEncoder binaryEncoder = EncoderFactory.get().binaryEncoder(baos, binaryEncoderReuse.get());
                DatumWriter<GenericRecord> datumWriter;
                if (useSpecific) {
                    datumWriter = new SpecificDatumWriter<>(payload.getSchema());
                } else {
                    datumWriter = new GenericDatumWriter<>(payload.getSchema());
                }
                datumWriter.write(payload, binaryEncoder);
                binaryEncoder.flush();
                baos.close();
                bytes = baos.toByteArray();
                if (log.isTraceEnabled()) {
                    log.trace("serialized payload='{}'", payload);//DatatypeConverter.printHexBinary(bytes));
                }
            }
        } catch (IOException e) {
            log.error("Unable to Serialize Event", e);
            throw new UncheckedIOException(e);
        }
        return bytes;
    }

    @Override
    public void close() {
        // do nothing
    }
}