package com.xxx.push.serv;

import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.xxx.push.model.Exchange;

import brave.Tracer;
import io.micrometer.core.instrument.composite.CompositeMeterRegistry;

@Component
public class DedupServ {
    @Autowired
    @Qualifier("tracer")
    private Tracer tracer;

    @Autowired
    @Qualifier("metrics")
    private CompositeMeterRegistry metrics;

    private Set<String> set = new ConcurrentSkipListSet<>();

    public boolean insert(Exchange exchange) {
        return set.add(exchange.getRequest().getRequestId());
    }

    public boolean seen(Exchange exchange) {
        return set.contains(exchange.getRequest().getRequestId());
    }

    public boolean delete(Exchange exchange) {
        return set.remove(exchange.getRequest().getRequestId());
    }
}
