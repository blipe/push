package com.xxx.push.util;

import java.util.Map;

public class ThreadUtil {
    public static void dump() {
        Map<Thread, StackTraceElement[]> allStackTraces = Thread.getAllStackTraces();
        allStackTraces.entrySet().forEach((entry) -> {
            Thread t = entry.getKey();
            boolean allow = true;
            for (StackTraceElement elem:entry.getValue()) {
                if (elem.toString().contains("/kafka.")) {
                    allow = false;
                    break;
                }
            }
            if (allow) {
                System.out.println(t.getName() + "\nIs Daemon " + t.isDaemon() + "\nIs Alive " + t.isAlive() + "\nState " + t.getState());
                for (StackTraceElement elem:entry.getValue()) {
                    System.out.print(elem);
                    System.out.println("\n");
                }
                System.out.println("\n");
            }
        });
    }
}
