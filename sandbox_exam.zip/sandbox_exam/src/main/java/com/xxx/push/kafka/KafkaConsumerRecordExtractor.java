package com.xxx.push.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;

import brave.Span;
import brave.Tracer;
import brave.propagation.TraceContext;
import brave.propagation.TraceContextOrSamplingFlags;

class KafkaConsumerRecordExtractor implements TraceContext.Extractor<ConsumerRecord<String, byte[]>> {
    private Tracer tracer;

    public KafkaConsumerRecordExtractor(Tracer tracer) {
        this.tracer = tracer;
    }

    @Override
    public TraceContextOrSamplingFlags extract(ConsumerRecord<String, byte[]> record) {
        Headers headers = record.headers();

        TraceContext.Builder builder = TraceContext.newBuilder();

        Long traceId = null;
        Long parentId = null;
        Long spanId = null;
        for (Header header : headers) {
            String key = header.key();
            if (key.equals("_trace_id")) {
                traceId = KafkaUtil.bytesToLong(header.value());
                continue;
            }
            if (key.equals("_parent_id")) {
                parentId = KafkaUtil.bytesToLong(header.value());
                continue;
            }
            if (key.equals("_span_id")) {
                spanId = KafkaUtil.bytesToLong(header.value());
                continue;
            }
        }

        if (traceId == null) {
            Span span = tracer.newTrace();
            TraceContext context = span.context();
            builder.traceId(context.traceId());
            builder.parentId(context.parentId());
            builder.spanId(context.spanId());
            span.abandon();
        } else {
            builder.traceId(traceId);
            builder.parentId(parentId);
            builder.spanId(spanId);
        }

        return TraceContextOrSamplingFlags.create(builder.build());
    }
}