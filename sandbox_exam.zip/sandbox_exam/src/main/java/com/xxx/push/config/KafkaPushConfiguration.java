package com.xxx.push.config;

import java.time.Clock;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.event.EventListener;
import org.springframework.kafka.KafkaException;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.event.ListenerContainerPartitionIdleEvent;
import org.springframework.kafka.event.ListenerContainerPartitionNoLongerIdleEvent;
import org.springframework.kafka.listener.BatchInterceptor;
import org.springframework.kafka.listener.ConsumerRecordRecoverer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.ContainerProperties.AckMode;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.listener.RecordInterceptor;
import org.springframework.kafka.listener.SeekUtils;
import org.springframework.kafka.listener.adapter.RecordFilterStrategy;
import org.springframework.kafka.support.LogIfLevelEnabled;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.util.backoff.FixedBackOff;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.xxx.push.Constants;
import com.xxx.push.model.Exchange;
import com.xxx.push.serde.AvroDeserializer;
import com.xxx.push.serde.AvroSerializer;
import com.xxx.push.util.Formatter;

import brave.Tracer;
import brave.Tracing;
import brave.handler.MutableSpan;
import brave.handler.SpanHandler;
import brave.propagation.TraceContext;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.composite.CompositeMeterRegistry;
//import io.micrometer.tracing.Tracer;
//import io.micrometer.tracing.brave.bridge.BraveTracer;
import lombok.extern.slf4j.Slf4j;

@Slf4j
//@EntityScan("com.xxx.push.domain")
//@EnableJpaRepositories("com.xxx.push.repository")
//@EnableTransactionManagement
@ComponentScan(basePackages = { "com.xxx.push" })
@Configuration()
//@TraceAutoConfiguration
@EnableConfigurationProperties(PushProperties.class)
public class KafkaPushConfiguration implements Constants {
    @Autowired
    private PushProperties pushProperties;

    @Bean(name = "exchangeSerializer")
    public AvroSerializer<Exchange> exchangeSerializer() {
        return new AvroSerializer<>(Exchange.getClassSchema());
    }

    @Bean(name = "exchangeDeserializer")
    public AvroDeserializer<Exchange> exchangeDeserializer() {
        return new AvroDeserializer<>(Exchange.getClassSchema());
    }

    @Bean(name = "clock")
    public Clock clock() {
        return Clock.systemUTC();
    }

    @Bean(name = "ttl")
    public long ttl() {
        return TimeUnit.DAYS.toMillis(3);
    }

    @Bean(name = "tracer")
    public Tracer tracer() {
        //brave.Tracer.
        //BraveTracer.create(braveTracing);
        return Tracing.newBuilder().localServiceName("push").addSpanHandler(new SpanHandler() {

            @Override
            public boolean begin(TraceContext context, MutableSpan span, TraceContext parent) {
                //log.info("begin span: " + span);
                return super.begin(context, span, parent);
            }

            @Override
            public boolean end(TraceContext context, MutableSpan span, Cause cause) {
                //log.info("end span: " + span);
                return super.end(context, span, cause);
            }

            @Override
            public boolean handlesAbandoned() {
                // TODO Auto-generated method stub
                return super.handlesAbandoned();
            }

        }).build().tracer();//.clock(clock()).
    }

    @Bean(name = "metrics")
    public CompositeMeterRegistry metrics() {
        return Metrics.globalRegistry;
    }

    @Bean(name = "kafkaAdmin")
    public KafkaAdmin kafkaAdmin(@Value("${kafka.bootstrap-servers}") final String bootstrapServers) {
        log.info("setting up kafkaAdmin: " + bootstrapServers);

        final Map<String, Object> config = new HashMap<>();
        config.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);

        KafkaAdmin kafkaAdmin = new KafkaAdmin(config);

        kafkaAdmin.setFatalIfBrokerNotAvailable(true);

        //kafkaAdmin.initialize();

        return kafkaAdmin;
    }

    @Bean
    public NewTopic requestTopic() {
        log.info("setting up requestTopic");
        return TopicBuilder.name(pushProperties.getRequestTopic()).partitions(Constants.PARTITIONS).replicas(1).build();
    }

    @Bean
    public NewTopic appleTopic() {
        log.info("setting up appleTopic");
        return TopicBuilder.name(pushProperties.getAppleTopic()).partitions(Constants.PARTITIONS).replicas(1).build();
    }

    @Bean
    public NewTopic androidTopic() {
        log.info("setting up androidTopic");
        return TopicBuilder.name(pushProperties.getAndroidTopic()).partitions(Constants.PARTITIONS).replicas(1).build();
    }

    @Bean
    public NewTopic outcomeTopic() {
        log.info("setting up outcomeTopic");
        return TopicBuilder.name(pushProperties.getOutcomeTopic()).partitions(Constants.PARTITIONS).replicas(1).build();
    }

    @Bean
    public NewTopic responseTopic() {
        log.info("setting up responseTopic");
        return TopicBuilder.name(pushProperties.getResponseTopic()).partitions(Constants.PARTITIONS).replicas(1).build();
    }

    //    @Bean(name = "kafkaListenerContainerFactory")
    //    public ConcurrentKafkaListenerContainerFactory<String, byte[]> kafkaListenerContainerFactory(final ConsumerFactory<String, byte[]> consumerFactory) {
    //        final ConcurrentKafkaListenerContainerFactory<String, byte[]> factory = new ConcurrentKafkaListenerContainerFactory<>();
    //        factory.setAckDiscarded(true);
    //        //        factory.setAfterRollbackProcessor(null);
    //        //        factory.setAutoStartup(null);
    //        //        factory.setBatchErrorHandler(null);
    //        //        factory.setBatchInterceptor(null);
    //        //        factory.setBatchListener(null);
    //        //        factory.setBatchMessageConverter(null);
    //        //        factory.setBatchToRecordAdapter(null);
    //        //        factory.setChangeConsumerThreadName(false);
    //        factory.setCommonErrorHandler(errorHandler());
    //        factory.setConcurrency(HardCoded.PARTITIONS);
    //        factory.setConsumerFactory(consumerFactory);
    //        //        factory.setContainerCustomizer(null);
    //        //        factory.setCorrelationHeaderName(null);
    //        //        factory.setErrorHandler(null);
    //        //        factory.setMessageConverter(null);
    //        //        factory.setMissingTopicsFatal(true);
    //        //        factory.setPhase(null);
    //        factory.setRecordFilterStrategy(recordFilterStrategy());
    //        //        factory.setRecordInterceptor(null);
    //        //        factory.setRecordMessageConverter(null);
    //        //        factory.setReplyHeadersConfigurer(null);
    //        //        factory.setReplyTemplate(null);
    //        //        factory.setThreadNameSupplier(null);
    //
    //        //        factory.getContainerProperties().setAsyncAcks(false);
    //        factory.getContainerProperties().setAckMode(AckMode.BATCH);//MANUAL);
    //        //        factory.getContainerProperties().setCommitCallback(new LoggingCommitCallback());
    //        //        factory.getContainerProperties().setAssignmentCommitOption(AssignmentCommitOption.LATEST_ONLY_NO_TX);
    //        factory.getContainerProperties().setCommitLogLevel(LogIfLevelEnabled.Level.TRACE);
    //        //        factory.getContainerProperties().setCommitRetries(3);
    //        //        factory.getContainerProperties().setConsumerRebalanceListener(null);
    //        //        factory.getContainerProperties().setConsumerStartTimeout(null);
    //        factory.getContainerProperties().setDeliveryAttemptHeader(true);
    //        //        factory.getContainerProperties().setEosMode(EOSMode.V2);
    //        //        factory.getContainerProperties().setFixTxOffsets(false);
    //        //        factory.getContainerProperties().setIdleBeforeDataMultiplier(5.0);
    //        //        factory.getContainerProperties().setIdleBetweenPolls(0);
    //        //        factory.getContainerProperties().setIdleEventInterval(null);
    //        //        factory.getContainerProperties().setIdlePartitionEventInterval(null);
    //        //        factory.getContainerProperties().setListenerTaskExecutor(null);
    //        //        factory.getContainerProperties().setLogContainerConfig(true);
    //        //        factory.getContainerProperties().setMessageListener(null);
    //        //        factory.getContainerProperties().setMicrometerEnabled(true);
    //        //        factory.getContainerProperties().setMicrometerTags(null);
    //        //        factory.getContainerProperties().setMonitorInterval(30);
    //        //        factory.getContainerProperties().setNoPollThreshold(3.0F);
    //        //        factory.getContainerProperties().setObservationConvention(null);
    //        //        factory.getContainerProperties().setObservationEnabled(false);
    //        //        factory.getContainerProperties().setOffsetAndMetadataProvider(null);
    //        //        factory.getContainerProperties().setPauseImmediate(false);
    //        //        factory.getContainerProperties().setPollTimeout(5000);
    //        //        factory.getContainerProperties().setPollTimeoutWhilePaused(null);
    //        //        factory.getContainerProperties().setRestartAfterAuthExceptions(false);
    //        //        factory.getContainerProperties().setScheduler(null);
    //        //        factory.getContainerProperties().setShutdownTimeout(10000);
    //        //        factory.getContainerProperties().setStopContainerWhenFenced(false);
    //        //        factory.getContainerProperties().setStopImmediate(false);
    //        //        factory.getContainerProperties().setSubBatchPerPartition(null);
    //        //        factory.getContainerProperties().setSyncCommits(true);
    //        //        factory.getContainerProperties().setSyncCommitTimeout(null);
    //        //        factory.getContainerProperties().setTransactionDefinition(null);
    //        //        factory.getContainerProperties().setTransactionManager(null);
    //        return factory;
    //    }

    @Bean(name = "requestKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, byte[]> requestKafkaListenerContainerFactory(final ConsumerFactory<String, byte[]> consumerFactory) {
        final ConcurrentKafkaListenerContainerFactory<String, byte[]> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setAckDiscarded(true);
        factory.setBatchListener(true);
        factory.setBatchInterceptor(batchInterceptor());
        //factory.setBatchToRecordAdapter(null);
        factory.setCommonErrorHandler(errorHandler());
        factory.setConcurrency(Constants.PARTITIONS);
        factory.setConsumerFactory(consumerFactory);
        factory.setRecordFilterStrategy(recordFilterStrategy());
        factory.setRecordInterceptor(recordInterceptor());

        ContainerProperties containerProperties = factory.getContainerProperties();
        containerProperties.setAckMode(AckMode.BATCH);//MANUAL);
        factory.getContainerProperties().setCommitLogLevel(LogIfLevelEnabled.Level.TRACE);
        factory.getContainerProperties().setDeliveryAttemptHeader(true);
        factory.getContainerProperties().setCheckDeserExWhenKeyNull(true);
        factory.getContainerProperties().setCheckDeserExWhenValueNull(true);
        factory.getContainerProperties().setPollTimeout(Constants.POLL_TIMEOUT);//default: 5000
        return factory;
    }

    @Bean(name = "androidKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, byte[]> androidKafkaListenerContainerFactory(final ConsumerFactory<String, byte[]> consumerFactory) {
        final ConcurrentKafkaListenerContainerFactory<String, byte[]> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setAckDiscarded(true);
        factory.setBatchListener(true);
        factory.setBatchInterceptor(batchInterceptor());
        //factory.setBatchToRecordAdapter(null);
        factory.setCommonErrorHandler(errorHandler());
        factory.setConcurrency(Constants.PARTITIONS);
        factory.setConsumerFactory(consumerFactory);
        factory.setRecordFilterStrategy(recordFilterStrategy());
        factory.setRecordInterceptor(recordInterceptor());

        ContainerProperties containerProperties = factory.getContainerProperties();
        containerProperties.setAckMode(AckMode.BATCH);//MANUAL);
        factory.getContainerProperties().setCommitLogLevel(LogIfLevelEnabled.Level.TRACE);
        factory.getContainerProperties().setDeliveryAttemptHeader(true);
        factory.getContainerProperties().setCheckDeserExWhenKeyNull(true);
        factory.getContainerProperties().setCheckDeserExWhenValueNull(true);
        factory.getContainerProperties().setPollTimeout(Constants.POLL_TIMEOUT);//default: 5000
        return factory;
    }

    @Bean(name = "appleKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, byte[]> appleKafkaListenerContainerFactory(final ConsumerFactory<String, byte[]> consumerFactory) {
        final ConcurrentKafkaListenerContainerFactory<String, byte[]> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setAckDiscarded(true);
        factory.setBatchListener(true);
        factory.setBatchInterceptor(batchInterceptor());
        //factory.setBatchToRecordAdapter(null);
        factory.setCommonErrorHandler(errorHandler());
        factory.setConcurrency(Constants.PARTITIONS);
        factory.setConsumerFactory(consumerFactory);
        factory.setRecordFilterStrategy(recordFilterStrategy());
        factory.setRecordInterceptor(recordInterceptor());

        ContainerProperties containerProperties = factory.getContainerProperties();
        containerProperties.setAckMode(AckMode.BATCH);//MANUAL);
        factory.getContainerProperties().setCommitLogLevel(LogIfLevelEnabled.Level.TRACE);
        factory.getContainerProperties().setDeliveryAttemptHeader(true);
        factory.getContainerProperties().setCheckDeserExWhenKeyNull(true);
        factory.getContainerProperties().setCheckDeserExWhenValueNull(true);
        factory.getContainerProperties().setPollTimeout(Constants.POLL_TIMEOUT);//default: 5000
        return factory;
    }

    @Bean(name = "outcomeKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, byte[]> outcomeKafkaListenerContainerFactory(final ConsumerFactory<String, byte[]> consumerFactory) {
        final ConcurrentKafkaListenerContainerFactory<String, byte[]> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setAckDiscarded(true);
        factory.setBatchListener(true);
        factory.setBatchInterceptor(batchInterceptor());
        //factory.setBatchToRecordAdapter(null);
        factory.setCommonErrorHandler(errorHandler());
        factory.setConcurrency(Constants.PARTITIONS);
        factory.setConsumerFactory(consumerFactory);
        factory.setRecordFilterStrategy(recordFilterStrategy());
        factory.setRecordInterceptor(recordInterceptor());

        ContainerProperties containerProperties = factory.getContainerProperties();
        containerProperties.setAckMode(AckMode.BATCH);//MANUAL);
        factory.getContainerProperties().setCommitLogLevel(LogIfLevelEnabled.Level.TRACE);
        factory.getContainerProperties().setDeliveryAttemptHeader(true);
        factory.getContainerProperties().setCheckDeserExWhenKeyNull(true);
        factory.getContainerProperties().setCheckDeserExWhenValueNull(true);
        factory.getContainerProperties().setPollTimeout(Constants.POLL_TIMEOUT);//default: 5000
        return factory;
    }

    @Bean(name = "responseKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, byte[]> responseKafkaListenerContainerFactory(final ConsumerFactory<String, byte[]> consumerFactory) {
        final ConcurrentKafkaListenerContainerFactory<String, byte[]> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setAckDiscarded(true);
        factory.setBatchListener(true);
        factory.setBatchInterceptor(batchInterceptor());
        //factory.setBatchToRecordAdapter(null);
        factory.setCommonErrorHandler(errorHandler());
        factory.setConcurrency(Constants.PARTITIONS);
        factory.setConsumerFactory(consumerFactory);
        factory.setRecordFilterStrategy(recordFilterStrategy());
        factory.setRecordInterceptor(recordInterceptor());

        ContainerProperties containerProperties = factory.getContainerProperties();
        containerProperties.setAckMode(AckMode.BATCH);//MANUAL);
        factory.getContainerProperties().setCommitLogLevel(LogIfLevelEnabled.Level.TRACE);
        factory.getContainerProperties().setDeliveryAttemptHeader(true);
        factory.getContainerProperties().setCheckDeserExWhenKeyNull(true);
        factory.getContainerProperties().setCheckDeserExWhenValueNull(true);
        factory.getContainerProperties().setPollTimeout(Constants.POLL_TIMEOUT);//default: 5000
        return factory;
    }

    @Bean(name = "batchInterceptor")
    public BatchInterceptor<String, byte[]> batchInterceptor() {
        return new BatchInterceptor<>() {
            @Override
            public ConsumerRecords<String, byte[]> intercept(ConsumerRecords<String, byte[]> records, Consumer<String, byte[]> consumer) {
                if (log.isTraceEnabled()) {
                    log.trace("batch interceptor");

                    records.forEach((record) -> {
                        log.trace(Formatter.format("Intercepted", record));
                    });
                }
                return records;
            }
        };
    }

    @Bean(name = "recordInterceptor")
    public RecordInterceptor<String, byte[]> recordInterceptor() {
        return new RecordInterceptor<>() {
            @Override
            public ConsumerRecord<String, byte[]> intercept(ConsumerRecord<String, byte[]> record, Consumer<String, byte[]> consumer) {
                if (log.isTraceEnabled()) {
                    log.trace("record interceptor");

                    log.trace(Formatter.format("Intercepted", record));
                }
                return record;
            }
        };
    }

    //    default void handleOtherException(Exception thrownException, Consumer<?, ?> consumer,
    //            MessageListenerContainer container, boolean batchListener) {
    //
    //        LogFactory.getLog(getClass()).error("'handleOtherException' is not implemented by this handler",
    //                thrownException);
    //    }

    //https://github.com/spring-projects/spring-kafka/issues/2036

    @Bean(name = "errorHandler")
    public DefaultErrorHandler errorHandler() {
        FixedBackOff backoff = new FixedBackOff(0, 9) {
            @Override
            public String toString() {
                return super.toString();
            }
        };

        //BatchListenerFailedException ex;

        ConsumerRecordRecoverer recoverer = new ConsumerRecordRecoverer() {
            @Override
            public void accept(ConsumerRecord<?, ?> record, Exception e) {
                log.warn(Formatter.format("recoverer", record));
                e.printStackTrace();
            }
        };

        DefaultErrorHandler errorHandler = new DefaultErrorHandler(recoverer, backoff) {
            @Override
            public void handleOtherException(Exception thrownException, Consumer<?, ?> consumer, MessageListenerContainer container, boolean batchListener) {
                log.warn("handling other exception: " + thrownException + ", batchListener: " + batchListener);

                //org.springframework.kafka.support.serializer.DeserializationException
                //Caused by: org.apache.kafka.common.errors.RecordDeserializationException: Error deserializing key/value for partition demo-non-idempotent-inbound-topic-9 at offset 0. If needed, please seek past the record to continue consumption.
                if (thrownException instanceof org.apache.kafka.common.errors.RecordDeserializationException deserEx) {
                    TopicPartition topicPartition = deserEx.topicPartition();
                    long offset = deserEx.offset();

                    log.warn(String.format("skipping group: %s, record: meta(topic=%s, partition=%d, offset=%d)", container.getGroupId(), topicPartition.topic(), topicPartition.partition(), offset));
                    thrownException.printStackTrace();

                    consumer.seek(topicPartition, offset + 1);

                    Map<TopicPartition, OffsetAndMetadata> offsets = new HashMap<>();
                    offsets.put(topicPartition, new OffsetAndMetadata(offset + 1));
                    try {
                        consumer.commitSync(offsets);
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        log.error("commit exception", e);
                    }

                } else {
                    super.handleOtherException(thrownException, consumer, container, batchListener);
                }
            }
        };
        errorHandler.setLogLevel(KafkaException.Level.DEBUG);
        return errorHandler;
    }

    //    @Bean
    //    public ConcurrentKafkaListenerContainerFactory<?, ?> kafkaListenerContainerFactory(ConcurrentKafkaListenerContainerFactoryConfigurer configurer, ConsumerFactory<Object, Object> kafkaConsumerFactory) {
    //        ConcurrentKafkaListenerContainerFactory<Object, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
    //        configurer.configure(factory, kafkaConsumerFactory);
    //        factory.getContainerProperties().setMissingTopicsFatal(false);
    //        factory.getContainerProperties().setCommitLogLevel(LogIfLevelEnabled.Level.INFO);
    //        return factory;
    //    }

    //22:54:59.HardCoded.PARTITIONS32 [main] [31mWARN [0;39m [36morg.springframework.kafka.config.MethodKafkaListenerEndpoint[0;39m - Filter strategy ignored when consuming 'ConsumerRecords' instead of a List id: org.springframework.kafka.KafkaListenerEndpointContainer#0
    @Bean(name = "recordFilterStrategy")
    public RecordFilterStrategy<String, byte[]> recordFilterStrategy() {
        return new RecordFilterStrategy<>() {
            @Override
            public boolean filter(ConsumerRecord<String, byte[]> record) {
                if (record.key().equals("EXPIRED")) {
                    log.warn(Formatter.format("Denied", record));
                    return true;
                } else {
                    if (log.isTraceEnabled()) {
                        log.trace(Formatter.format("Allowed", record));
                    }
                    return false;
                }
            }
        };
    }

    @Bean(name = "consumerFactory")
    @Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public ConsumerFactory<String, byte[]> consumerFactory(@Value("${kafka.bootstrap-servers}") final String bootstrapServers, @Value("${kafka.consumer.maxPollIntervalMs}") final String maxPollIntervalMs) {
        log.info("setting up consumerFactory: " + bootstrapServers);

        final Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        config.put(ConsumerConfig.GROUP_ID_CONFIG, "com-xxx-kafka");
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        //config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ByteArrayDeserializer.class);
        //        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);
        //        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);
        //        config.put(ErrorHandlingDeserializer.KEY_DESERIALIZER_CLASS, StringDeserializer.class);
        //        config.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, StringDeserializer.class);
        config.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPollIntervalMs);
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, String.valueOf(Constants.MAX_POLL_RECORDS));
        config.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000");

        //KafkaAvroDeserializer deserializer;

        //11:15:35.315 [org.springframework.kafka.KafkaListenerEndpointContainer#3-0-C-1] [1;31mERROR[0;39m [36mcom.xxx.kafka.KafkaDemoConfiguration$3[0;39m - Backoff FixedBackOff{interval=0, currentAttempts=1, maxAttempts=0} exhausted for demo-non-idempotent-inbound-topic-0@0
        //11:15:35.316 [org.springframework.kafka.KafkaListenerEndpointContainer#3-0-C-1] [39mDEBUG[0;39m [36mcom.xxx.kafka.KafkaDemoConfiguration$3[0;39m - Skipping seek of: demo-non-idempotent-inbound-topic-0@0
        SeekUtils x;

        StringDeserializer keyDeserializer = new StringDeserializer();
        ErrorHandlingDeserializer<byte[]> valueDeserializer = new ErrorHandlingDeserializer<>(new ByteArrayDeserializer());

        ConsumerFactory<String, byte[]> consumerFactory = new DefaultKafkaConsumerFactory<>(config, keyDeserializer, valueDeserializer);

        consumerFactory.addListener(new ConsumerFactory.Listener<>() {
            public void consumerAdded(String id, Consumer<String, byte[]> consumer) {
                log.info("consumer added: " + id + ", consumer: " + consumer);
            }

            public void consumerRemoved(String id, Consumer<String, byte[]> consumer) {
                log.info("consumer removed: " + id + ", consumer: " + consumer);
            }
        });

        return consumerFactory;
    }

    @Bean(name = "kafkaTemplate")
    public KafkaTemplate<String, byte[]> kafkaTemplate(final ProducerFactory<String, byte[]> producerFactory) {
        //log.info("setting up kafkaTemplate: " + bootstrapServers);

        return new KafkaTemplate<>(producerFactory);
    }

    @Bean(name = "requestTemplate")
    public KafkaTemplate<String, byte[]> requestTemplate(final ProducerFactory<String, byte[]> producerFactory) {
        //log.info("setting up requestTemplate: " + bootstrapServers);

        return new KafkaTemplate<>(producerFactory);
    }

    @Bean(name = "androidTemplate")
    public KafkaTemplate<String, byte[]> androidTemplate(final ProducerFactory<String, byte[]> producerFactory) {
        //log.info("setting up androidTemplate: " + bootstrapServers);

        return new KafkaTemplate<>(producerFactory);
    }

    @Bean(name = "appleTemplate")
    public KafkaTemplate<String, byte[]> appleTemplate(final ProducerFactory<String, byte[]> producerFactory) {
        //log.info("setting up appleTemplate: " + bootstrapServers);

        return new KafkaTemplate<>(producerFactory);
    }

    @Bean(name = "outcomeTemplate")
    public KafkaTemplate<String, byte[]> outcomeTemplate(final ProducerFactory<String, byte[]> producerFactory) {
        //log.info("setting up outcomeTemplate: " + bootstrapServers);

        return new KafkaTemplate<>(producerFactory);
    }

    @Bean(name = "responseTemplate")
    public KafkaTemplate<String, byte[]> responseTemplate(final ProducerFactory<String, byte[]> producerFactory) {
        //log.info("setting up responseTemplate: " + bootstrapServers);

        return new KafkaTemplate<>(producerFactory);
    }

    //    @Bean
    //    public KafkaTransactionManager<?, ?> kafkaTransactionManager() {
    //        KafkaTransactionManager<?, ?> kafkaTransactionManager = new KafkaTransactionManager<>(producerFactory());
    //        // ...
    //        return kafkaTransactionManager;
    //    }

    //    @Bean
    //    public static PropertySourcesPlaceholderConfigurer ppc() {
    //        return new PropertySourcesPlaceholderConfigurer();
    //    }

    @Bean(name = "producerFactory")
    @Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public ProducerFactory<String, byte[]> producerFactory(@Value("${kafka.bootstrap-servers}") final String bootstrapServers) {
        log.info("setting up producerFactory: " + bootstrapServers);

        final Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, "1");//ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION_FOR_IDEMPOTENCE);
        config.put(ProducerConfig.RETRIES_CONFIG, "10");
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);

        //KafkaAvroSerializer serializer;

        StringSerializer keySerializer = new StringSerializer();
        ByteArraySerializer valueSerializer = new ByteArraySerializer();

        ProducerFactory<String, byte[]> producerFactory = new DefaultKafkaProducerFactory<>(config, keySerializer, valueSerializer);

        producerFactory.addListener(new ProducerFactory.Listener<String, byte[]>() {
            @Override
            public void producerAdded(String id, Producer<String, byte[]> producer) {
                log.info("producer added: " + id + ", producer: " + producer);
            }

            @Override
            public void producerRemoved(String id, Producer<String, byte[]> producer) {
                log.info("producer removed: " + id + ", producer: " + producer);
            }
        });

        return producerFactory;
    }

    @EventListener
    public void handleEvent(ListenerContainerPartitionIdleEvent event) {
        log.info("handle event: " + event);
    }

    @EventListener
    public void handleEvent(ListenerContainerPartitionNoLongerIdleEvent event) {
        log.info("handle event: " + event);
    }

    @Bean(name = "requestExecutor")
    public ExecutorService requestExecutor() {
        ExecutorService executor = Executors.newFixedThreadPool(Constants.THREAD_POOL_SIZE, new ThreadFactoryBuilder().setNameFormat("Request-%d").build());
        return executor;
    }

    @Bean(name = "androidExecutor")
    public ExecutorService androidExecutor() {
        ExecutorService executor = Executors.newFixedThreadPool(Constants.THREAD_POOL_SIZE, new ThreadFactoryBuilder().setNameFormat("Android-%d").build());
        return executor;
    }

    @Bean(name = "appleExecutor")
    public ExecutorService appleExecutor() {
        ExecutorService executor = Executors.newFixedThreadPool(Constants.THREAD_POOL_SIZE, new ThreadFactoryBuilder().setNameFormat("Apple-%d").build());
        return executor;
    }

    @Bean(name = "outcomeExecutor")
    public ExecutorService outcomeExecutor() {
        ExecutorService executor = Executors.newFixedThreadPool(Constants.THREAD_POOL_SIZE, new ThreadFactoryBuilder().setNameFormat("Outcome-%d").build());
        return executor;
    }

    @Bean(name = "responseExecutor")
    public ExecutorService responseExecutor() {
        ExecutorService executor = Executors.newFixedThreadPool(Constants.THREAD_POOL_SIZE, new ThreadFactoryBuilder().setNameFormat("Response-%d").build());
        return executor;
    }

    //    @Bean(name = "dedupServ")
    //    public DedupServ dedupServ() {
    //        return new DedupServ();
    //    }
    //
    //    @Bean(name = "tokenServ")
    //    public TokenServ tokenServ() {
    //        return new TokenServ();
    //    }
    //
    //    @Bean(name = "outcomeServ")
    //    public OutcomeServ outcomeServ() {
    //        return new OutcomeServ();
    //    }
    //
    //    @Bean(name = "androidApi")
    //    public AndroidApi androidApi() {
    //        return new AndroidApi();
    //    }
    //
    //    @Bean(name = "appleApi")
    //    public AppleApi appleApi() {
    //        return new AppleApi();
    //    }

}
