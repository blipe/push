package com.xxx.push.kafka;

import java.time.Clock;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.avro.Schema;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.log.LogAccessor;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ListenerUtils;
import org.springframework.kafka.support.SendResult;
import org.springframework.kafka.support.serializer.DeserializationException;
import org.springframework.kafka.support.serializer.SerializationUtils;
import org.springframework.stereotype.Component;

import com.xxx.push.Constants;
import com.xxx.push.Stats;
import com.xxx.push.config.PushProperties;
import com.xxx.push.model.Exchange;
import com.xxx.push.model.Response;
import com.xxx.push.model.Type;
import com.xxx.push.serde.AvroDeserializer;
import com.xxx.push.serde.AvroSerializer;
import com.xxx.push.serv.AndroidApi;
import com.xxx.push.serv.Api;
import com.xxx.push.serv.AppleApi;
import com.xxx.push.serv.DedupServ;
import com.xxx.push.serv.OutcomeServ;
import com.xxx.push.serv.TokenServ;
import com.xxx.push.util.Formatter;
import com.xxx.push.util.ThreadUtil;

import brave.Tracer;
import io.micrometer.core.instrument.composite.CompositeMeterRegistry;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/*
add token, seqLen, seqNum, partial to response

add micrometer

add trace/brave
*/
@Slf4j
@RequiredArgsConstructor
@Component
public class KafkaPushConsumer implements Constants {
    @Autowired
    private PushProperties pushProperties;

    @Autowired
    @Qualifier("tracer")
    private Tracer tracer;

    @Autowired
    @Qualifier("metrics")
    private CompositeMeterRegistry metrics;

    @Autowired
    @Qualifier("exchangeSerializer")
    private AvroSerializer<Exchange> serializer;

    @Autowired
    @Qualifier("exchangeDeserializer")
    private AvroDeserializer<Exchange> deserializer;

    @Autowired
    @Qualifier("clock")
    private Clock clock;

    @Autowired
    @Qualifier("ttl")
    private long ttl;

    @Autowired
    @Qualifier("dedupServ")
    private DedupServ dedupServ;

    @Autowired
    @Qualifier("tokenServ")
    private TokenServ tokenServ;

    @Autowired
    @Qualifier("outcomeServ")
    private OutcomeServ outcomeServ;

    @Autowired
    @Qualifier("androidApi")
    private AndroidApi androidApi;

    @Autowired
    @Qualifier("appleApi")
    private AppleApi appleApi;

    @Autowired
    @Qualifier("requestExecutor")
    private ExecutorService requestExecutor;
    @Autowired
    @Qualifier("androidExecutor")
    private ExecutorService androidExecutor;
    @Autowired
    @Qualifier("appleExecutor")
    private ExecutorService appleExecutor;
    @Autowired
    @Qualifier("outcomeExecutor")
    private ExecutorService outcomeExecutor;
    @Autowired
    @Qualifier("responseExecutor")
    private ExecutorService responseExecutor;

    //    @Autowired
    //    @Qualifier("requestTopic")
    //    private String requestTopic;
    //    @Autowired
    //    @Qualifier("androidTopic")
    //    private String androidTopic;
    //    @Autowired
    //    @Qualifier("appleTopic")
    //    private String appleTopic;
    //    @Autowired
    //    @Qualifier("outcomeTopic")
    //    private String outcomeTopic;
    //    @Autowired
    //    @Qualifier("responseTopic")
    //    private String responseTopic;

    @Autowired
    @Qualifier("requestTemplate")
    private KafkaTemplate<String, byte[]> requestTemplate;
    @Autowired
    @Qualifier("androidTemplate")
    private KafkaTemplate<String, byte[]> androidTemplate;
    @Autowired
    @Qualifier("appleTemplate")
    private KafkaTemplate<String, byte[]> appleTemplate;
    @Autowired
    @Qualifier("outcomeTemplate")
    private KafkaTemplate<String, byte[]> outcomeTemplate;
    @Autowired
    @Qualifier("responseTemplate")
    private KafkaTemplate<String, byte[]> responseTemplate;

    //    private AtomicBoolean requestName = new AtomicBoolean(false);
    //    private AtomicBoolean androidName = new AtomicBoolean(false);
    //    private AtomicBoolean appleName = new AtomicBoolean(false);
    //    private AtomicBoolean outcomeName = new AtomicBoolean(false);
    //    private AtomicBoolean responseName = new AtomicBoolean(false);

    @PostConstruct
    public void postConstruct() {
        //ThreadUtil.dump();
    }

    @PreDestroy
    public void preDestroy() {
        //ThreadUtil.dump();
    }

    //org.springframework.kafka.config.MethodKafkaListenerEndpoint - Filter strategy ignored when consuming 'ConsumerRecords' instead of a List id: org.springframework.kafka.KafkaListenerEndpointContainer#0
    //KafkaListenerEndpointContainer
    @KafkaListener(topics = REQUEST_TOPIC, groupId = "requestKafkaConsumerGroup", containerFactory = "requestKafkaListenerContainerFactory")
    public void listenRequest(List<ConsumerRecord<String, byte[]>> records) throws InterruptedException {//, final Acknowledgment acknowledgment) {
        Schema schema = Exchange.getClassSchema();

        String name = "request";

        Thread thread = Thread.currentThread();
        if (!thread.getName().endsWith(" | " + name)) {
            thread.setName(thread.getName() + " | " + name);
        }

        if (log.isTraceEnabled()) {
            log.trace("Batch {}: {}", name, records.size());
        }

        long readTime = System.currentTimeMillis();

        KafkaTemplate<String, byte[]> sender = requestTemplate;

        List<Callable<Void>> tasks = new ArrayList<>();

        records.forEach(record -> {
            //TraceContextOrSamplingFlags extracted = new KafkaConsumerRecordExtractor(tracer).extract(record);
            //Span span = tracer.nextSpan(extracted);
            //span.start();
            //span.finish();

            long num = Stats.requestListenCount.incrementAndGet();

            if (record.key() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.KEY_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record key at offset {} could not be deserialized", record.offset(), ex);
                }
            } else if (record.value() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.VALUE_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record value at offset {} could not be deserialized", record.offset(), ex);
                }
            } else {
                if (log.isTraceEnabled()) {
                    log.trace(Formatter.format(name, record));
                }

                Exchange exchange = deserialize(record);

                Callable<Void> task = () -> {
                    if (!dedupServ.seen(exchange)) {
                        Stats.requestUniqueCount.incrementAndGet();

                        Stats.topicPartitions.computeIfAbsent(REQUEST_TOPIC, (k) -> new ConcurrentHashMap<>()).computeIfAbsent(record.partition(), (k) -> new AtomicLong()).incrementAndGet();

                        if (isExpired(record, exchange)) {
                            log.warn("detected expired exchange: " + exchange);

                            Stats.requestExpiredCount.incrementAndGet();

                            Response response = Api.EXPIRED;

                            //exchange = Exchange.newBuilder(exchange).setResponse(response).build();//copy?
                            exchange.setResponse(response);

                            List<Header> headers = propogateHeaders(schema, record, name, readTime);

                            byte[] ser = serialize(OUTCOME_TOPIC, exchange);

                            ProducerRecord<String, byte[]> rec = new ProducerRecord<>(OUTCOME_TOPIC, null, record.key(), ser, headers);
                            sendAsync(sender, rec);
                        } else {
                            List<String> tokens = exchange.getRequest().getTokens();

                            boolean editted = false;
                            if (tokens.isEmpty()) {
                                tokens = tokenServ.lookup(exchange);

                                //exchange = Exchange.newBuilder(exchange).build();//copy?
                                exchange.getRequest().setTokens(tokens);

                                editted = true;
                            }

                            Stats.tokenCount.incrementAndGet();
                            Stats.tokenTotal.addAndGet(tokens.size());

                            List<Header> headers = propogateHeaders(schema, record, name, readTime);

                            ProducerRecord<String, byte[]> rec;
                            if (tokens.isEmpty()) {
                                Response response;
                                log.warn("detected no tokens exchange: " + exchange);

                                if (exchange.getRequest().getType() == Type.ANDROID) {
                                    Stats.androidNoTokensCount.incrementAndGet();
                                } else {
                                    Stats.appleNoTokensCount.incrementAndGet();
                                }

                                response = Api.NOT_FOUND;

                                //exchange = Exchange.newBuilder(exchange).setResponse(response).build();//copy?
                                exchange.setResponse(response);

                                byte[] ser = record.value();
                                if (editted) {
                                    ser = serialize(OUTCOME_TOPIC, exchange);
                                }
                                rec = new ProducerRecord<>(OUTCOME_TOPIC, null, record.key(), ser, headers);
                            } else {
                                if (exchange.getRequest().getType() == Type.ANDROID) {
                                    byte[] ser = record.value();
                                    if (editted) {
                                        ser = serialize(ANDROID_TOPIC, exchange);
                                    }
                                    rec = new ProducerRecord<>(ANDROID_TOPIC, null, record.key(), ser, headers);
                                } else {
                                    byte[] ser = record.value();
                                    if (editted) {
                                        ser = serialize(APPLE_TOPIC, exchange);
                                    }
                                    rec = new ProducerRecord<>(APPLE_TOPIC, null, record.key(), ser, headers);
                                }
                            }
                            sendAsync(sender, rec);
                        }
                    } else {
                        log.warn("skipping duplicate exchange: " + exchange);

                        Stats.requestDedupCount.incrementAndGet();
                    }

                    return null;
                };
                tasks.add(task);
            }
        });

        List<Future<Void>> futures = requestExecutor.invokeAll(tasks);
        for (Future<Void> future : futures) {
            try {
                future.get();
            } catch (InterruptedException e) {
                future.cancel(true);
                log.error("execution interrupted", e);
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                log.error("execution exception", cause);
            }
        }

        //System.out.println(records.size() + "/" + (System.currentTimeMillis()-readTime) + "ms request");

        //throw new BatchListenerFailedException();
    }

    //KafkaListenerEndpointContainer
    @KafkaListener(topics = ANDROID_TOPIC, groupId = "androidKafkaConsumerGroup", containerFactory = "androidKafkaListenerContainerFactory")
    public void listenAndroid(List<ConsumerRecord<String, byte[]>> records) throws InterruptedException {//, final Acknowledgment acknowledgment) {
        Schema schema = Exchange.getClassSchema();

        String name = "android";

        Thread thread = Thread.currentThread();
        if (!thread.getName().endsWith(" | " + name)) {
            thread.setName(thread.getName() + " | " + name);
        }

        if (log.isTraceEnabled()) {
            log.trace("Batch {}: {}", name, records.size());
        }

        long readTime = System.currentTimeMillis();

        KafkaTemplate<String, byte[]> sender = androidTemplate;

        List<Callable<Void>> tasks = new ArrayList<>();

        records.forEach(record -> {
            long num = Stats.androidListenCount.incrementAndGet();

            if (record.key() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.KEY_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record key at offset {} could not be deserialized", record.offset(), ex);
                }
            } else if (record.value() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.VALUE_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record value at offset {} could not be deserialized", record.offset(), ex);
                }
            } else {
                if (log.isTraceEnabled()) {
                    log.trace(Formatter.format(name, record));
                }

                Exchange exchange = deserialize(record);

                Callable<Void> task = () -> {
                    if (dedupServ.insert(exchange)) {
                        Stats.androidUniqueCount.incrementAndGet();

                        Stats.topicPartitions.computeIfAbsent(ANDROID_TOPIC, (k) -> new ConcurrentHashMap<>()).computeIfAbsent(record.partition(), (k) -> new AtomicLong()).incrementAndGet();

                        Response response;
                        if (isExpired(record, exchange)) {
                            log.warn("detected expired exchange: " + exchange);

                            Stats.androidExpiredCount.incrementAndGet();

                            response = Api.EXPIRED;
                        } else {
                            response = androidApi.handle(androidExecutor, exchange);
                        }

                        //exchange = Exchange.newBuilder(exchange).setResponse(response).build();//copy?
                        exchange.setResponse(response);

                        List<Header> headers = propogateHeaders(schema, record, name, readTime);

                        byte[] ser = serialize(OUTCOME_TOPIC, exchange);

                        ProducerRecord<String, byte[]> rec = new ProducerRecord<>(OUTCOME_TOPIC, null, record.key(), ser, headers);
                        sendAsync(sender, rec);
                    } else {
                        log.warn("skipping duplicate exchange: " + exchange);

                        Stats.androidDedupCount.incrementAndGet();
                    }

                    return null;
                };
                tasks.add(task);
            }
        });

        List<Future<Void>> futures = androidExecutor.invokeAll(tasks);
        for (Future<Void> future : futures) {
            try {
                future.get();
            } catch (InterruptedException e) {
                future.cancel(true);
                log.error("execution interrupted", e);
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                log.error("execution exception", cause);
            }
        }

        //System.out.println(records.size() + "/" + (System.currentTimeMillis()-readTime) + "ms android");

        //throw new BatchListenerFailedException();
    }

    //KafkaListenerEndpointContainer
    @KafkaListener(topics = APPLE_TOPIC, groupId = "appleKafkaConsumerGroup", containerFactory = "appleKafkaListenerContainerFactory")
    public void listenApple(List<ConsumerRecord<String, byte[]>> records) throws InterruptedException {//, final Acknowledgment acknowledgment) {
        Schema schema = Exchange.getClassSchema();

        String name = "apple";

        Thread thread = Thread.currentThread();
        if (!thread.getName().endsWith(" | " + name)) {
            thread.setName(thread.getName() + " | " + name);
        }

        if (log.isTraceEnabled()) {
            log.trace("Batch {}: {}", name, records.size());
        }

        long readTime = System.currentTimeMillis();

        KafkaTemplate<String, byte[]> sender = appleTemplate;

        List<Callable<Void>> tasks = new ArrayList<>();

        records.forEach(record -> {
            long num = Stats.appleListenCount.incrementAndGet();

            if (record.key() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.KEY_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record key at offset {} could not be deserialized", record.offset(), ex);
                }
            } else if (record.value() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.VALUE_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record value at offset {} could not be deserialized", record.offset(), ex);
                }
            } else {
                if (log.isTraceEnabled()) {
                    log.trace(Formatter.format(name, record));
                }

                //exchange = Exchange.newBuilder(exchange).setResponse(response).build();//copy?
                Exchange exchange = deserialize(record);

                Callable<Void> task = () -> {
                    if (dedupServ.insert(exchange)) {
                        Stats.appleUniqueCount.incrementAndGet();

                        Stats.topicPartitions.computeIfAbsent(APPLE_TOPIC, (k) -> new ConcurrentHashMap<>()).computeIfAbsent(record.partition(), (k) -> new AtomicLong()).incrementAndGet();

                        Response response;
                        if (isExpired(record, exchange)) {
                            log.warn("detected expired exchange: " + exchange);

                            Stats.appleExpiredCount.incrementAndGet();

                            response = Api.EXPIRED;
                        } else {
                            response = appleApi.handle(appleExecutor, exchange);
                        }

                        exchange.setResponse(response);

                        List<Header> headers = propogateHeaders(schema, record, name, readTime);

                        byte[] ser = serialize(OUTCOME_TOPIC, exchange);

                        ProducerRecord<String, byte[]> rec = new ProducerRecord<>(OUTCOME_TOPIC, null, record.key(), ser, headers);
                        sendAsync(sender, rec);
                    } else {
                        log.warn("skipping duplicate exchange: " + exchange);

                        Stats.appleDedupCount.incrementAndGet();
                    }

                    return null;
                };
                tasks.add(task);
            }
        });

        List<Future<Void>> futures = appleExecutor.invokeAll(tasks);
        for (Future<Void> future : futures) {
            try {
                future.get();
            } catch (InterruptedException e) {
                future.cancel(true);
                log.error("execution interrupted", e);
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                log.error("execution exception", cause);
            }
        }

        //System.out.println(records.size() + "/" + (System.currentTimeMillis()-readTime) + "ms apple");

        //throw new BatchListenerFailedException();
    }

    //KafkaListenerEndpointContainer
    @KafkaListener(topics = OUTCOME_TOPIC, groupId = "outcomeKafkaConsumerGroup", containerFactory = "outcomeKafkaListenerContainerFactory")
    public void listenOutcome(List<ConsumerRecord<String, byte[]>> records) throws InterruptedException {//, final Acknowledgment acknowledgment) {
        Schema schema = Exchange.getClassSchema();

        String name = "outcome";

        Thread thread = Thread.currentThread();
        if (!thread.getName().endsWith(" | " + name)) {
            thread.setName(thread.getName() + " | " + name);
        }

        if (log.isTraceEnabled()) {
            log.trace("Batch {}: {}", name, records.size());
        }

        long readTime = System.currentTimeMillis();

        KafkaTemplate<String, byte[]> sender = outcomeTemplate;

        List<Callable<Void>> tasks = new ArrayList<>();

        records.forEach(record -> {
            long num = Stats.outcomeListenCount.incrementAndGet();

            Stats.topicPartitions.computeIfAbsent(OUTCOME_TOPIC, (k) -> new ConcurrentHashMap<>()).computeIfAbsent(record.partition(), (k) -> new AtomicLong()).incrementAndGet();

            if (record.key() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.KEY_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record key at offset {} could not be deserialized", record.offset(), ex);
                }
            } else if (record.value() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.VALUE_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record value at offset {} could not be deserialized", record.offset(), ex);
                }
            } else {
                if (log.isTraceEnabled()) {
                    log.trace(Formatter.format(name, record));
                }

                Exchange exchange = deserialize(record);

                Callable<Void> task = () -> {
                    outcomeServ.store(exchange);

                    List<Header> headers = propogateHeaders(schema, record, name, readTime);

                    ProducerRecord<String, byte[]> rec = new ProducerRecord<>(RESPONSE_TOPIC, null, record.key(), record.value(), headers);
                    sendAsync(sender, rec);

                    return null;
                };
                tasks.add(task);
            }
        });

        List<Future<Void>> futures = outcomeExecutor.invokeAll(tasks);
        for (Future<Void> future : futures) {
            try {
                future.get();
            } catch (InterruptedException e) {
                future.cancel(true);
                log.error("execution interrupted", e);
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                log.error("execution exception", cause);
            }
        }

        //System.out.println(records.size() + "/" + (System.currentTimeMillis()-readTime) + "ms outcome");

        //throw new BatchListenerFailedException();
    }

    //KafkaListenerEndpointContainer
    @KafkaListener(topics = RESPONSE_TOPIC, groupId = "responseKafkaConsumerGroup", containerFactory = "responseKafkaListenerContainerFactory")
    public void listenResponse(List<ConsumerRecord<String, byte[]>> records) {//, final Acknowledgment acknowledgment) {
        Schema schema = Exchange.getClassSchema();

        String name = "response";

        Thread thread = Thread.currentThread();
        if (!thread.getName().endsWith(" | " + name)) {
            thread.setName(thread.getName() + " | " + name);
        }

        if (log.isTraceEnabled()) {
            log.trace("Batch {}: {}", name, records.size());
        }

        long readTime = System.currentTimeMillis();

        KafkaTemplate<String, byte[]> sender = responseTemplate;

        records.forEach(record -> {
            long num = Stats.responseListenCount.incrementAndGet();

            Stats.topicPartitions.computeIfAbsent(RESPONSE_TOPIC, (k) -> new ConcurrentHashMap<>()).computeIfAbsent(record.partition(), (k) -> new AtomicLong()).incrementAndGet();

            if (record.key() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.KEY_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record key at offset {} could not be deserialized", record.offset(), ex);
                }
            } else if (record.value() == null) {
                DeserializationException ex = ListenerUtils.getExceptionFromHeader(record, SerializationUtils.VALUE_DESERIALIZER_EXCEPTION_HEADER, new LogAccessor(KafkaUtil.class));//this.logger);
                if (ex != null) {
                    log.error("Record value at offset {} could not be deserialized", record.offset(), ex);
                }
            } else {
                if (log.isTraceEnabled()) {
                    log.trace(Formatter.format(name, record));
                }

                Exchange exchange = deserialize(record);

                if (num > Constants.TOTAL_EXCHANGES) {
                    System.out.println("extra exchange: " + exchange);
                }

                long request_read_time = KafkaUtil.bytesToLong(record.headers().lastHeader("_request_read_time").value());

                if (num % 100000 == 0) {
                    System.out.println(num + "| " + (record.timestamp() - request_read_time) + "ms between request and response");

                    ThreadUtil.dump();
                }

                List<Header> headers = propogateHeaders(schema, record, name, readTime);

                //ProducerRecord<String, byte[]> rec = new ProducerRecord<>(XXX_TOPIC, null, record.key(), record.value(), headers);
                //sendAsync(sender, rec);
            }
        });

        //System.out.println(records.size() + "/" + (System.currentTimeMillis()-readTime) + "ms response");

        //throw new BatchListenerFailedException();
    }

    protected List<Header> copyCustomHeaders(ConsumerRecord<String, byte[]> record) {
        List<Header> headers = new ArrayList<>();
        for (Header header : record.headers()) {
            String key = header.key();
            if (key.startsWith("_")) {
                headers.add(header);//new RecordHeader(key, header.value()));
            }
        }
        return headers;
    }

    protected List<Header> propogateHeaders(Schema schema, ConsumerRecord<String, byte[]> record, String name, long readTime) {
        List<Header> headers = copyCustomHeaders(record);
        headers.add(new RecordHeader(String.format("_%s_read_time", name), KafkaUtil.longToBytes(readTime)));
        headers.add(new RecordHeader(String.format("_%s_record_time", name), KafkaUtil.longToBytes(record.timestamp())));
        headers.add(new RecordHeader(String.format("_%s_write_time", name), KafkaUtil.longToBytes(System.currentTimeMillis())));

        String schemaName = getAvroSchemaName(schema);
        String schemaVersion = getAvroSchemaVersion(schema);
        headers.add(new RecordHeader(String.format("_schema_name", schemaName), KafkaUtil.stringToBytes(schemaName)));
        headers.add(new RecordHeader(String.format("_schema_version", schemaVersion), KafkaUtil.stringToBytes(schemaVersion)));

        //MutableSpan span = new MutableSpan();

        return headers;
    }

    protected String getAvroSchemaName(Schema schema) {
        return schema.getFullName();
    }

    protected String getAvroSchemaVersion(Schema schema) {
        return String.valueOf(schema.getObjectProp("version"));
    }

    protected boolean isExpired(ConsumerRecord<String, byte[]> record, Exchange exchange) {
        long now = clock.millis();//System.currentTimeMillis();
        return record.timestamp() < (now - ttl) || exchange.getRequest().getExpiration() < now;
    }

    protected byte[] serialize(String topic, Exchange exchange) {
        return serializer.serialize(topic, exchange);
    }

    protected Exchange deserialize(ConsumerRecord<String, byte[]> record) {
        return deserializer.deserialize(record.topic(), record.headers(), record.value());
    }

    protected void sendAsync(KafkaTemplate<String, byte[]> sender, ProducerRecord<String, byte[]> rec) {
        //Span span = tracer.nextSpan();
        //new KafkaProducerRecordInjector().inject(span.context(), rec);

        CompletableFuture<SendResult<String, byte[]>> future = sender.send(rec);
        future.whenComplete((result, ex) -> {
            if (ex != null) {
                log.error("send exception", ex);
            } else {
                if (log.isTraceEnabled()) {
                    log.trace("sent rec: {}, result: {}", rec, result);
                }
            }
        });
    }

    public static void main(String[] args) {
        System.out.println(TimeUnit.DAYS.toMillis(3));
    }
}
