package com.xxx.push;

public interface Constants {
    public static final String REQUEST_TOPIC = "request-topic";
    public static final String ANDROID_TOPIC = "android-topic";
    public static final String APPLE_TOPIC = "apple-topic";
    public static final String OUTCOME_TOPIC = "outcome-topic";
    public static final String RESPONSE_TOPIC = "response-topic";

    public static final int TOTAL_EXCHANGES = 200_000;

    public static final long ANDROID_API_SLEEP_LONG = 6000;
    public static final long ANDROID_API_SLEEP_SHORT = 50;
    public static final long APPLE_API_SLEEP_LONG = 6000;
    public static final long APPLE_API_SLEEP_SHORT = 50;
    public static final int API_LONG_MOD = 20000;
    public static final int API_EX_MOD = 25000;
    public static final int API_ERR_MOD = 25001;

    public static final long DB_SERV_SLEEP_SHORT = 10;

    public static final long TOKEN_SERV_SLEEP_SHORT = 5;

    public static final long EXPIRATION_LONG = 2 * 300000;//10 minutes
    public static final long EXPIRATION_SHORT = 300000;//5 minutes

    public static final int PARTITIONS = 8;

    public static final int POLL_TIMEOUT = 1000;//default: 5000
    public static final int MAX_POLL_RECORDS = 100;

    public static final int THREAD_POOL_SIZE = 128;
}
