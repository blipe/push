package com.xxx.push.util;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

public class Formatter {
    public static String format(String name, ConsumerRecord<?, ?> record) {
        return String.format("%s record(headers=%s, key=%s value=%s) meta(topic=%s, partition=%d, offset=%d)", name, record.headers(), record.key(), record.value(), record.topic(), record.partition(), record.offset());
    }

    public static String format(String name, ProducerRecord<?, ?> record) {
        return String.format("%s record(headers=%s, key=%s value=%s)", name, record.headers(), record.key(), record.value());
    }

    public static String format(String name, ProducerRecord<?, ?> record, RecordMetadata metadata) {
        return String.format("%s record(headers=%s, key=%s value=%s) meta(topic=%s, partition=%d, offset=%d)", name, record.headers(), record.key(), record.value(), metadata.topic(), metadata.partition(), metadata.offset());
    }
}
