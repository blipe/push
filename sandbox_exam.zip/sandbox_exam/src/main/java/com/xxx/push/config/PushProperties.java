package com.xxx.push.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@ConfigurationProperties(prefix = "push")
@Data
public class PushProperties {
    private String requestTopic = "request-topic";
    private String androidTopic = "android-topic";
    private String appleTopic = "apple-topic";
    private String outcomeTopic = "outcome-topic";
    private String responseTopic = "response-topic";

    //private String partitions = "8";
}