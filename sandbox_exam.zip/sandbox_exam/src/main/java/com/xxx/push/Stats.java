package com.xxx.push;

import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class Stats {
    public static AtomicLong requestListenCount = new AtomicLong();
    public static AtomicLong androidListenCount = new AtomicLong();
    public static AtomicLong appleListenCount = new AtomicLong();
    public static AtomicLong outcomeListenCount = new AtomicLong();
    public static AtomicLong responseListenCount = new AtomicLong();

    public static AtomicLong androidApiCallCount = new AtomicLong();
    public static AtomicLong androidApiCallTime = new AtomicLong();
    public static Map<Integer, AtomicLong> androidApiResponseCodes = new ConcurrentHashMap<>();

    public static AtomicLong appleApiCallCount = new AtomicLong();
    public static AtomicLong appleApiCallTime = new AtomicLong();
    public static Map<Integer, AtomicLong> appleApiResponseCodes = new ConcurrentHashMap<>();

    public static AtomicLong tokenServCallCount = new AtomicLong();
    public static AtomicLong tokenServCallTime = new AtomicLong();

    public static AtomicLong outcomeServCallCount = new AtomicLong();
    public static AtomicLong outcomeServCallTime = new AtomicLong();

    public static AtomicLong requestUniqueCount = new AtomicLong();
    public static AtomicLong androidUniqueCount = new AtomicLong();
    public static AtomicLong appleUniqueCount = new AtomicLong();

    public static AtomicLong requestExpiredCount = new AtomicLong();
    public static AtomicLong androidExpiredCount = new AtomicLong();
    public static AtomicLong appleExpiredCount = new AtomicLong();

    public static AtomicLong requestDedupCount = new AtomicLong();
    public static AtomicLong androidDedupCount = new AtomicLong();
    public static AtomicLong appleDedupCount = new AtomicLong();

    public static AtomicLong tokenCount = new AtomicLong();
    public static AtomicLong tokenTotal = new AtomicLong();
    public static AtomicLong androidNoTokensCount = new AtomicLong();
    public static AtomicLong appleNoTokensCount = new AtomicLong();

    public static Map<String, Map<Integer, AtomicLong>> topicPartitions = new ConcurrentHashMap<>();

    public static void dump() {
        System.out.println("Request listen count: " + requestListenCount);
        System.out.println("Request unique count: " + requestUniqueCount);
        System.out.println("Request expired count: " + requestExpiredCount);
        System.out.println("Request dedup count: " + requestDedupCount);

        System.out.println("Android listen count: " + androidListenCount);
        System.out.println("Android unique count: " + androidUniqueCount);
        System.out.println("Android expired count: " + androidExpiredCount);
        System.out.println("Android dedup count: " + androidDedupCount);

        System.out.println("Apple listen count: " + appleListenCount);
        System.out.println("Apple unique count: " + appleUniqueCount);
        System.out.println("Apple expired count: " + appleExpiredCount);
        System.out.println("Apple dedup count: " + appleDedupCount);

        System.out.println("Outcome listen count: " + outcomeListenCount);
        System.out.println("Response listen count: " + responseListenCount);

        System.out.println("Android API count: " + androidApiCallCount);
        System.out.println("Android API avg time(ms): " + ((double) androidApiCallTime.get() / androidApiCallCount.get()));
        System.out.println("Android no tokens count: " + androidNoTokensCount);
        System.out.println("Android API response codes:");
        androidApiResponseCodes.forEach((k, v) -> {
            System.out.println("\t" + k + ": " + v);
        });

        System.out.println("Apple API count: " + appleApiCallCount);
        System.out.println("Apple API avg time(ms): " + ((double) appleApiCallTime.get() / appleApiCallCount.get()));
        System.out.println("Apple no tokens count: " + appleNoTokensCount);
        System.out.println("Apple API response codes:");
        appleApiResponseCodes.forEach((k, v) -> {
            System.out.println("\t" + k + ": " + v);
        });

        System.out.println("Token Serv count: " + tokenServCallCount);
        System.out.println("Token Serv avg time(ms): " + ((double) tokenServCallTime.get() / tokenServCallCount.get()));

        System.out.println("Outcome Serv count: " + outcomeServCallCount);
        System.out.println("Outcome Serv avg time(ms): " + ((double) outcomeServCallTime.get() / outcomeServCallCount.get()));

        System.out.println("Token count: " + tokenCount);
        System.out.println("Token avg: " + ((double) tokenTotal.get() / tokenCount.get()));

        System.out.println("Topic partitions: ");
        new TreeMap<>(topicPartitions).forEach((k, v) -> {
            System.out.println("\t" + k + ": " + new TreeMap<>(v));
        });
    }
}