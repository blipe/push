package com.xxx.push.kafka;

import java.nio.charset.StandardCharsets;

import com.google.common.primitives.Longs;

public class KafkaUtil {
    public static byte[] stringToBytes(String value) {
        return value.getBytes(StandardCharsets.UTF_8);
    }

    public static String bytesToString(byte[] bytes) {
        return new String(bytes, StandardCharsets.UTF_8);
    }

    //    public static byte[] longToBytes(long value) {
    //        return stringToBytes(String.valueOf(value));
    //    }
    //
    //    public static long bytesToLong(byte[] bytes) {
    //        return Long.parseLong(bytesToString(bytes));
    //    }

    public static byte[] longToBytes(long value) {
        return Longs.toByteArray(value);
    }

    public static long bytesToLong(final byte[] bytes) {
        return Longs.fromByteArray(bytes);
    }
}
